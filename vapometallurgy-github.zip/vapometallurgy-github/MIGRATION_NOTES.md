# Migration notes

## What was prepared

- Rebuilt the public Wix content as a static, responsive one-page website.
- Preserved the main sections: Home, Approach, Team, Publications, and Contact.
- Added GitHub Pages-ready structure under `docs/`.
- Added `.nojekyll` so GitHub Pages serves the static files directly.
- Added a custom `404.html` page.
- Added SVG favicon, social preview image, and process diagram so the site does not depend on Wix-hosted design assets.
- Added an optional GitHub Actions workflow for Pages deployment.
- Added README deployment instructions, custom-domain notes, and content review checklist.

## Wix-specific items not portable to GitHub Pages

Wix forms, Wix analytics, Wix editor metadata, and Wix-hosted design components are not directly portable to GitHub Pages. This repo replaces them with static HTML, CSS, JavaScript, and a mailto-based contact form.

## Contact form replacement options

For GitHub Pages, a contact form needs a third-party endpoint or institutional backend. Common options include:

- A University of Waterloo-approved form endpoint.
- Formspree, Basin, Getform, or another static-site form service.
- A serverless function hosted outside GitHub Pages.

## Profile links

Some original team links pointed to LinkedIn pages. Because LinkedIn can block automated access, the static site uses accessible University of Waterloo profile/contact pages where available. Review the team links before publishing.
