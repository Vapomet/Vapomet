# Vapometallurgy website

Static GitHub-ready version of the Vapometallurgy research website.

This repository is prepared for GitHub Pages. The public website files live in `docs/`, so the repository can be published either from the `main` branch `/docs` folder or with the included GitHub Actions workflow.

## Repository structure

```text
.
├── .github/workflows/pages.yml   # Optional GitHub Pages Actions deployment
├── docs/                         # Public website root
│   ├── index.html                # One-page website
│   ├── 404.html                  # Custom not-found page
│   ├── .nojekyll                 # Serve files directly without Jekyll processing
│   ├── CNAME.example             # Custom-domain template
│   ├── site.webmanifest          # Basic web app metadata
│   └── assets/
│       ├── css/styles.css
│       ├── js/main.js
│       └── img/                  # SVG favicon, social preview, process graphic
├── MIGRATION_NOTES.md
├── CONTENT_CHECKLIST.md
├── LICENSE
└── README.md
```

## Publish with GitHub Pages from `/docs`

1. Create a new GitHub repository.
2. Upload or push this repository content.
3. In GitHub, open **Settings > Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/docs`.
6. Save. GitHub will publish the site at the URL shown in the Pages settings screen.

## Publish with the included GitHub Actions workflow

1. Push this repository to GitHub.
2. In **Settings > Pages**, set the source to **GitHub Actions**.
3. Push to `main`, or run the workflow manually from the **Actions** tab.

The workflow publishes the contents of `docs/` only.

## Local preview

From the repository root:

```bash
python3 -m http.server 8000 --directory docs
```

Then open `http://localhost:8000`.

## Contact form note

GitHub Pages is static hosting and does not process server-side forms. The current form opens the visitor's email client with a prefilled message using `mailto:vbarahim@uwaterloo.ca`.

For production-grade stored submissions, replace the form `action` in `docs/index.html` with a form service endpoint such as Formspree, Basin, Getform, or a University of Waterloo-approved form handler.

## Custom domain

1. In GitHub, open **Settings > Pages** and add the custom domain first.
2. Configure DNS with your registrar.
3. Rename `docs/CNAME.example` to `docs/CNAME` and replace the commented example with your actual domain.
4. Commit and push.
5. Enable **Enforce HTTPS** once GitHub makes the option available.

Do not use wildcard DNS records for GitHub Pages.

## Editing content

Most text is in `docs/index.html`. Styling is in `docs/assets/css/styles.css`, and the small mobile-navigation script is in `docs/assets/js/main.js`.

Before publishing, review `CONTENT_CHECKLIST.md` for items that need owner confirmation.
