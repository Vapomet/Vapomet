const navToggle = document.querySelector('[data-nav-toggle]');
const navLinks = document.querySelector('[data-nav-links]');
const header = document.querySelector('[data-header]');

if (navToggle && navLinks) {
  navToggle.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('is-open');
    navToggle.setAttribute('aria-expanded', String(isOpen));
    navToggle.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
  });

  navLinks.addEventListener('click', (event) => {
    if (event.target instanceof HTMLAnchorElement) {
      navLinks.classList.remove('is-open');
      navToggle.setAttribute('aria-expanded', 'false');
      navToggle.setAttribute('aria-label', 'Open menu');
    }
  });
}

const sections = Array.from(document.querySelectorAll('main section[id]'));
const links = Array.from(document.querySelectorAll('.nav-links a[href^="#"]'));

const setActiveLink = () => {
  const offset = header ? header.offsetHeight + 18 : 92;
  const current = sections
    .map((section) => ({ id: section.id, top: section.getBoundingClientRect().top - offset }))
    .filter((section) => section.top <= 0)
    .pop();

  links.forEach((link) => {
    const isActive = current && link.getAttribute('href') === `#${current.id}`;
    link.classList.toggle('is-active', Boolean(isActive));
  });
};

setActiveLink();
window.addEventListener('scroll', setActiveLink, { passive: true });
window.addEventListener('resize', setActiveLink);
