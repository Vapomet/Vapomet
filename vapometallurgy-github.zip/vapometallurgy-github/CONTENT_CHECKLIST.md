# Content checklist before launch

Review these items before making the GitHub Pages site public.

## Required checks

- Confirm the preferred public title: `Vapometallurgy`, `Vapomet`, or another official name.
- Confirm the contact email: `vbarahim@uwaterloo.ca`.
- Confirm the location text: `200 University Avenue West, Waterloo, Ontario, N2L 3G1, Canada`.
- Confirm the copyright footer: `Copyright 2026 Vapomet.com. All rights reserved.`
- Confirm the battery-cell revenue claim and add a citation on the live page if needed.
- Confirm whether the site should use `vapomet.com`, a GitHub Pages URL, or another custom domain.
- Confirm all team roles and profile links.
- Confirm the publication list, order, titles, authors, venues, years, and links.

## Optional improvements

- Add real team headshots if approved.
- Add a University of Waterloo logo only if brand-use permission and correct files are available.
- Replace the mailto form with a production form endpoint.
- Add analytics only after confirming privacy and institutional requirements.
- Add a sitemap once the final public domain is known.
